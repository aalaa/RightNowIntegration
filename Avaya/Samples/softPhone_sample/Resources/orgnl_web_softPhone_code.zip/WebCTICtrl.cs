﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Nortel.CCT;

namespace WebCTI
{
    public partial class WebCTICtrl : UserControl
    {
        private Toolkit theToolkit = null;
        private ISession theSession = null;

        private TerminalConnectionState mState = TerminalConnectionState.Unknown;
        private ITerminalConnection mConnect = null;
        private IAddress mAddress = null;

        private IAgent mAgent = null;

        private ITerminal chosenTerminal = null;

        private bool bAgtAddr = false;
        private bool bAgtLoggedIn = false;
        private bool bDisableAgt = false;
        private bool bSIPPBX = false;
        private bool bPendingXfer = false;
        private bool bPendingConf = false;

        private IContact XferContact = null;
        private IContact ConfContact = null;

        private ITerminalConnection[] existingConnects = null;
        private IAddress[] chosenAddressList = null;
        private IAddress chosenAddress = null;

        private TermConnStateEventHandler theConnectionHandler;
        private ContactPropertyEventHandler theContactHandler;
        private UserPropertyEventHandler theAgentHandler;
        private SessionDisconnectedEventHandler theDisconnectHandler;

        public WebCTICtrl()
        {
            InitializeComponent();
        }

        private void mLogin_Click(object sender, EventArgs e)
        {
            mStringt.Text = string.Empty;
            mKVP1t.Text = string.Empty;
            mKVP2t.Text = string.Empty;
            mBinaryt.Text = string.Empty;
            mUUIt.Text = string.Empty;

            mError.Text = string.Empty;

            mAgent = null;

            mText.ForeColor = Color.Red;
            mText.Text = "CONNECTING...";
            mLogin.Enabled = false;

            theToolkit = new Toolkit();

            try
            {
                // Connect to CCT Server
                theToolkit.Server = mServerIP.Text;
                theToolkit.Port = 29373;
                theToolkit.Credentials = new CCTCredentials(mCCTUser.Text, mCCTDomain.Text, mCCTPwd.Text);
                theSession = theToolkit.Connect();
            }
            catch
            {
                mLogin.Enabled = true;
                mText.ForeColor = Color.Red;
                mText.Text = "LOGIN FAILED";
                return;
            }

            // Setup session event handlers
            theConnectionHandler = theToolkit.CreateGUIEventHandler(
              new TermConnStateEventHandler(OnConnectionStateChange),Form.ActiveForm);
            theSession.TermConnStateChanged += theConnectionHandler;

            theContactHandler = theToolkit.CreateGUIEventHandler(
              new ContactPropertyEventHandler(OnContactStateChange),Form.ActiveForm);
            theSession.ContactPropertyChanged += theContactHandler;

            theAgentHandler = theToolkit.CreateGUIEventHandler(
              new UserPropertyEventHandler(OnAgentStateChange), Form.ActiveForm);
            theSession.UserPropertyChanged += theAgentHandler;

            // Setup disconnect event handler
            theDisconnectHandler = new SessionDisconnectedEventHandler(OnDisconnect);
            theToolkit.SessionDisconnected += theDisconnectHandler;

            mText.ForeColor = Color.Green;
            mText.Text = "LOGGED IN";

            bDisableAgt = false;
            bAgtAddr = false;
            bAgtLoggedIn = false;
            bSIPPBX = false;
            bPendingXfer = false;
            bPendingConf = false;

            chosenTerminal = null;
            existingConnects = null;
            chosenAddressList = null;

            chosenAddress = null;

            mState = TerminalConnectionState.Unknown;
            mConnect = null;
            mAddress = null;

            ResetButtons();

            mTerminals.Items.Clear();
            mTerminals.Enabled = true;

            // Set 'default' Agent for each terminal
            List<IAgentTerminal> lTerm = new List<IAgentTerminal>();

            foreach (ITerminal assignT in theSession.Terminals)
            {
                if (assignT.DefaultContactType == "Voice")
                {
                    mTerminals.Items.Add(assignT);
                        lTerm.Add(assignT as IAgentTerminal);
                }
            }

            if(lTerm.Count > 0)
            {
                foreach(IAgent IAgtSS in theSession.Agents)
                {
                    if (lTerm.Count == 0) break;
                    if (IAgtSS.Terminals.Length != 0)
                    {
                        if (IAgtSS.StaticVoiceTerminal == null)
                        {
                            IAgtSS.StaticVoiceTerminal = IAgtSS.Terminals[0];
                            lTerm.Remove(IAgtSS.Terminals[0]);
                        }
                    }
                    else
                    {
                        IAgtSS.StaticVoiceTerminal = lTerm[0];
                        lTerm.RemoveAt(0);
                    }
                }
            }

            if (mTerminals.Items.Count > 0)
            {
                mTerminals.SelectedIndex = 0;
                chosenTerminal = mTerminals.SelectedItem as ITerminal;
                chosenAddressList = chosenTerminal.RelatedAddresses;
            }
            else
            {
                mCCTDomain.Enabled = false;
                mCCTPwd.Enabled = false;
                mCCTUser.Enabled = false;
                mServerIP.Enabled = false;

                mLogout.Enabled = true;
                return;
            }

            mAddr.Items.Clear();
            mAddr.Enabled = true;
          
            foreach (IAddress assignA in chosenAddressList)
            {
                if(assignA.RelatedTerminals.Contains(chosenTerminal))
                {
                    mAddr.Items.Add(assignA);
                }
            }

            if (mAddr.Items.Count > 0)
            {
                mAddr.SelectedIndex = 0;
                chosenAddress = mAddr.SelectedItem as IAddress;

                // Check if SIP provider - only check once at session login
                if (chosenAddress is IAgentAddress)
                {
                    if (chosenAddress.URI != null) bSIPPBX = true;
                }

                // Check for existing calls etc
                CheckAddressState();
            }
            else mAddr.Enabled = false;

            if (theSession.Agents.Length == 0)
            {
                bDisableAgt = true;
                mText.ForeColor = Color.Red;
                mText.Text = "NO AGENTS ASSIGNED";
            }

            mCCTDomain.Enabled = false;
            mCCTPwd.Enabled = false;
            mCCTUser.Enabled = false;
            mServerIP.Enabled = false;

            mLogout.Enabled = true;
        }

        private void OnAgentStateChange(UserPropertyEventArgs e)
        {
            foreach(IAgent Agt in theSession.Agents)
            {
                if ((Agt.UserID == e.Sender.UserID) && (Agt.StaticVoiceTerminal == (IAgentTerminal)chosenTerminal))
                {
                    if (e.CurrentCapabilities.CanGetReadyStatus && e.ChangedProperty == AgentProperty.ReadyStatus)
                    {
                        mAready.Enabled = true;
                        mAready.Text = (Agt.IsReady) ? "Ready" : "NReady";
                    }
                    if (e.CurrentCapabilities.CanLogout && e.ChangedProperty == AgentProperty.LoggedIn)
                     {
                        bAgtLoggedIn = true;
                        mAgent = Agt;

                        mAgtButton.Enabled = true;
                        mAgtButton.Text = "Logout";
                        mAready.Enabled = true;
                        mAready.Text = (Agt.IsReady) ? "Ready" : "NReady";
                    }
                    if (e.CurrentCapabilities.CanLogin && e.ChangedProperty == AgentProperty.LoggedIn)
                    {
                        bAgtLoggedIn = false;
                        //mAgent = null;

                        mAgtButton.Enabled = true;
                        mAgtButton.Text = "AgentLogin";
                        mAready.Enabled = false;
                    }
                }
            }
        }

        private void OnConnectionStateChange(TermConnStateEventArgs e)
        {
            if ((chosenAddress == e.Connection.Address) && (!bPendingXfer) && (!bPendingConf))
            {
                mConnect = e.TerminalConnection;
                mState = e.NewState;
                mAddress = e.Connection.Address;

                if (mState == TerminalConnectionState.Ringing || mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)
                {
                    mText.ForeColor = Color.Green;
                    mText.Text = "ACTIVE";
                    mAddr.Enabled = false;

                    // Check for intrinsic
                    if ((e.Contact.Intrinsics != null) && (e.Contact.Capabilities.CanGetIntrinsics == true))
                    {
                        foreach (string IntrinsicID in e.Contact.Intrinsics.Keys)
                        {
                            if (IntrinsicID == "Skillset") mSkillsetTxt.Text = e.Contact.Intrinsics[IntrinsicID];

                            // SIP call this intrinsic is also stored as UUI data
                            if (IntrinsicID == "SIP_CALLER_DISPLAY") mCLIDTxt.Text = e.Contact.Intrinsics[IntrinsicID];
                        }
                    }

                    if (mState != TerminalConnectionState.Ringing) // Do not check for attached data on ringing
                    {
                        if (bSIPPBX) // Cannot check UUI unless SIP call
                        {
                            // Check for UUI data
                            UserUserInfo localUUI = e.Contact.UUI;

                            if ((localUUI != null) && (localUUI.StringData.Length > 0) && (e.Contact.Capabilities.CanGetUUI == true))
                            {
                                mUUIBut.Enabled = true;
                                if (localUUI.MayBeBinary)
                                {
                                    StringBuilder text = new StringBuilder(1024);
                                    foreach (byte b in localUUI.BinaryData) text.AppendFormat("{0} ", b.ToString("X2"));
                                    mUUIt.Text = text.ToString();
                                }
                                else mUUIt.Text = localUUI.StringData;
                            }
                        }

                        // Check for attached data
                        if ((e.Contact.Data != null) && (e.Contact.Capabilities.CanGetAttachedData == true))
                        {
                            AttachedData tempAData = e.Contact.Data;
                            CheckData(tempAData);
                        }
                    }

                    if (bAgtAddr && !bDisableAgt) // Agent call
                    {
                        if (bSIPPBX) // Check agent call is inbound or outbound if SIP
                        {
                            // Cater for both Agent and DN buttons
                            if (e.Contact.CallingAddress == chosenAddress.Name) // Call is outbound
                            {
                                mAgtButton.Enabled = false; // Disable agent login key

                                if (mState == TerminalConnectionState.Ringing) // Ringback from far end
                                {
                                    mMakeCall.Text = "HangUp";
                                    mMakeCall.Enabled = true;
                                    mDialNum.Enabled = false;
                                }
                                if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)
                                {
                                    mMakeCall.Text = "HangUp";
                                    mMakeCall.Enabled = true;
                                    mDialNum.Enabled = false;
                                }
                            }
                            else // Call is inbound
                            {
                                mMakeCall.Enabled = false; // Disable outbound
                                mDialNum.Enabled = false;

                                if (mState == TerminalConnectionState.Ringing) // Local ringing
                                {
                                    mAgtButton.Text = "Answer";
                                    mAgtButton.Enabled = true;
                                    mAxferNum.Enabled = false;
                                    mAxfer.Enabled = false;
                                    mAready.Enabled = false;
                                    mAConf.Enabled = false;
                                }
                                if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)
                                {
                                    mAgtButton.Text = "Hangup";
                                    mAgtButton.Enabled = true;
                                    mAxferNum.Enabled = true;
                                    mAxfer.Enabled = true;
                                    mAready.Enabled = false;
                                    mAConf.Enabled = true;
                                }
                            }
                        }
                        else // non SIP agent - no outbound
                        {
                            if (mState == TerminalConnectionState.Ringing)
                            {
                                mAgtButton.Text = "Answer";
                                mAgtButton.Enabled = true;
                                mAxferNum.Enabled = false;
                                mAxfer.Enabled = false;
                                mAready.Enabled = false;
                                mAConf.Enabled = false;
                            }
                            if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse)
                            {
                                mAgtButton.Text = "Hangup";
                                mAgtButton.Enabled = true;
                                mAxferNum.Enabled = true;
                                mAxfer.Enabled = true;
                                mAready.Enabled = false;
                                mAConf.Enabled = true;
                            }
                            if (mState == TerminalConnectionState.Held)
                            {
                                // Hold buttons
                            }
                        }
                    }
                    else // non SIP DN call
                    {
                        if (mState == TerminalConnectionState.Ringing)
                        {
                            if (e.Contact.CallingAddress == chosenAddress.Name) // Call is outbound - ringback from far end
                            {
                                mMakeCall.Text = "Hangup";
                            }
                            else // Call is inbound - local rining
                            {
                                mMakeCall.Text = "Answer";
                            }
                            mMakeCall.Enabled = true;
                            mDialNum.Enabled = false;
                        }
                        if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)
                        {
                            mMakeCall.Text = "HangUp";
                            mMakeCall.Enabled = true;
                            mDialNum.Enabled = false;
                        }
                    }
                }

                else if (mState == TerminalConnectionState.Unknown || mState == TerminalConnectionState.Idle || mState == TerminalConnectionState.Dropped)
                {
                    // Ignore drop of interim call leg
                    if (e.Reason != Reason.ConferenceComplete)
                    {
                        mText.ForeColor = Color.Green;
                        mText.Text = "IDLE";

                        ResetButtons(); // Clear attached data fields

                        mAddr.Enabled = true;
                        if (bAgtAddr && !bDisableAgt)
                        {
                            if (bSIPPBX) // Set both buttons
                            {
                                mMakeCall.Text = "MakeCall";
                                mMakeCall.Enabled = true;
                                mDialNum.Enabled = true;
                            }
                            mAgtButton.Text = "Logout";
                            mAgtButton.Enabled = true;
                            mAxfer.Enabled = false;
                            mAxferNum.Enabled = false;
                            mAready.Enabled = true;
                            mAConf.Enabled = false;
                        }
                        else
                        {
                            mMakeCall.Text = "MakeCall";
                            mMakeCall.Enabled = true;
                            mDialNum.Enabled = true;
                        }
                    }
                }
            }
            else if ((chosenAddress == e.Connection.Address) && (bPendingXfer || bPendingConf))
            {
                // Conference or transfer has been initiated
                if (bPendingXfer)
                {
                    if (((bSIPPBX) && (e.Reason == Reason.ConsultInitiated)) || ((!bSIPPBX) && (e.Reason == Reason.TransferInitiated)))
                    {
                        // Complete transfer
                        try
                        {
                            if (bSIPPBX) mConnect.CompleteSupervisedTransfer(mConnect.ConsultContact);
                            else mConnect.CompleteSupervisedTransfer(XferContact);
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                        bPendingXfer = false;
                        XferContact = null;
                    }
                }
                else if (bPendingConf)
                {
                    if (((bSIPPBX) && (e.Reason == Reason.ConsultInitiated)) || ((!bSIPPBX) && (e.Reason == Reason.ConferenceInitiated)))
                    {
                        // Complete conference
                        try
                        {
                            if (bSIPPBX) mConnect.CompleteConference(mConnect.ConsultContact);
                            // non SIP needs call answered to complete conference - unhold drops new conf leg to regain call control
                            else mConnect.CompleteConference(ConfContact);
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                            // Unhold requires AHA on CS1000 PBX to automatically drop other call leg
                            if (!bSIPPBX) mConnect.Unhold();
                        }
                        bPendingConf = false;
                        ConfContact = null;
                    }
                }
            }
        }

        private void OnContactStateChange(ContactPropertyEventArgs e)
        {
            if (chosenAddress == e.Address)
            {
                // Attached data has changed
                if (e.ChangedProperty == ContactProperty.AttachedData)
                {
                    if((e.Sender.Data != null) && (e.Sender.Capabilities.CanGetAttachedData == true))
                    {
                        AttachedData tempCData = e.Sender.Data;
                        CheckData(tempCData);
                    }
                }

                // UUI data has changed
                if (e.ChangedProperty == ContactProperty.UserUserInfo)
                {
                    UserUserInfo localUUI = e.Sender.UUI; ;
                    if ((localUUI != null) && (localUUI.StringData.Length > 0) && (e.Sender.Capabilities.CanGetUUI == true) && bSIPPBX)
                    {
                        mUUIBut.Enabled = true;
                        if (localUUI.MayBeBinary)
                        {
                            StringBuilder text = new StringBuilder(1024);
                            foreach (byte b in localUUI.BinaryData) text.AppendFormat("{0} ", b.ToString("X2"));
                            mUUIt.Text = text.ToString();
                        }
                        else mUUIt.Text = localUUI.StringData;
                    }
                }

                // Intrinsic has changed
                if (e.ChangedProperty == ContactProperty.Intrinsics)
                {
                    if ((e.Sender.Intrinsics != null) && (e.Sender.Capabilities.CanGetIntrinsics == true))
                    {
                        foreach (string IntrinsicID in e.Sender.Intrinsics.Keys)
                        {
                            if (IntrinsicID == "Skillset") mSkillsetTxt.Text = e.Sender.Intrinsics[IntrinsicID];

                            // SIP call this intrinsic is also stored as UUI data
                            if (IntrinsicID == "SIP_CALLER_DISPLAY") mCLIDTxt.Text = e.Sender.Intrinsics[IntrinsicID];
                        }
                    }
                }
            }
        }

        private void OnDisconnect(SessionDisconnectedEventArgs e)
        {
            mText.ForeColor = Color.Red;
            mText.Text = "NOT CONNECTED";

            mCCTDomain.Enabled = true;
            mCCTPwd.Enabled = true;
            mCCTUser.Enabled = true;
            mServerIP.Enabled = true;

            mTerminals.Enabled = false;
            mAddr.Enabled = false;
            mLogout.Enabled = false;
            mLogin.Enabled = true;

            ResetButtons();
        }

        private void mLogout_Click(object sender, EventArgs e)
        {
            // Invokes OnDisconnect Event Handler automatically
            theToolkit.Disconnect();
        }

        private void mTerminals_SelectedIndexChanged(object sender, EventArgs e)
        {
            bAgtLoggedIn = false;
            chosenTerminal = mTerminals.SelectedItem as ITerminal;

            chosenAddressList = chosenTerminal.RelatedAddresses;

            mAddr.Items.Clear();
            mAddr.Enabled = true;
          
            foreach (IAddress assignA in chosenAddressList)
            {
                if(assignA.RelatedTerminals.Contains(chosenTerminal))
                {
                    mAddr.Items.Add(assignA);
                }
            }

            if (mAddr.Items.Count > 0)
            {
                mAddr.SelectedIndex = 0;
                chosenAddress = mAddr.SelectedItem as IAddress;

                // mAddr_SelectedIndexChanged will be invoked for address change logic
            }
            else
            {
                //mAddr.SelectedIndex = -1;
                mAddr.Enabled = false;
            }
        }

        private void mMakeCall_Click(object sender, EventArgs e)
        {
            // Answer, abandon, hangup or make call
            if (mState == TerminalConnectionState.Unknown || mState == TerminalConnectionState.Idle || mState == TerminalConnectionState.Dropped)
            {
                // Make call
                mText.ForeColor = Color.Green;
                mText.Text = "DIALLING";
                try
                {
                    chosenTerminal.Originate(chosenAddress, mDialNum.Text);
                }
                catch (Exception Ex)
                {
                    mText.ForeColor = Color.Red;
                    mText.Text = "FAILED";
                    mError.Text = Ex.Message;
                }
            }
            else
            {
                if(mState==TerminalConnectionState.Ringing)
                {
                    // Abandon outbound or Answer inbound
                    if (mConnect.Contact.CallingAddress == chosenAddress.Name) // Outbound
                    {
                        try
                        {
                            mConnect.Connection.Disconnect();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                    else // Inbound
                    {
                        if (!bSIPPBX) // SIP DN calls alert on agent key
                        {
                            try
                            {
                                mConnect.Answer();
                            }
                            catch (Exception Ex)
                            {
                                mText.ForeColor = Color.Red;
                                mText.Text = "FAILED";
                                mError.Text = Ex.Message;
                            }
                        }
                    }
                }
                if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.Held)
                {
                    // Hangup
                    try
                    {
                        mConnect.Connection.Disconnect();
                    }
                    catch (Exception Ex)
                    {
                        mText.ForeColor = Color.Red;
                        mText.Text = "FAILED";
                        mError.Text = Ex.Message;
                    }
                }
            }
        }

        private void mAddr_SelectedIndexChanged(object sender, EventArgs e)
        {
            chosenAddress = mAddr.SelectedItem as IAddress;

            // Check for existing calls etc
            CheckAddressState();
        }

        private void mAgtButton_Click(object sender, EventArgs e)
        {
            if (bAgtAddr && !bDisableAgt)
            {
                if (bAgtLoggedIn)
                {
                    if (mState == TerminalConnectionState.Ringing)
                    {
                        try
                        {
                            mConnect.Answer();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                    if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)
                    {
                        try
                        {
                            mConnect.Connection.Disconnect();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                    if (mState == TerminalConnectionState.Unknown || mState == TerminalConnectionState.Idle || mState == TerminalConnectionState.Dropped)
                    {
                        IAgentTerminal temp = mAgent.StaticVoiceTerminal;

                        try
                        {
                            mAgent.Logout();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }

                        if (mAgent.StaticVoiceTerminal == null) mAgent.StaticVoiceTerminal = temp;
                    }
                }
                else
                {
                    if (bSIPPBX && (mState == TerminalConnectionState.Ringing)) // SIP inbound DN call - outbound on DN key
                    {
                        try
                        {
                            mConnect.Answer();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                        return; // No agent function needed
                    }

                    if (bSIPPBX && (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse || mState == TerminalConnectionState.Held)) // SIP inbound DN call - outbound on DN key
                    {
                        try
                        {
                            mConnect.Connection.Disconnect();
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                        return; // No agent function needed
                    }
    
                    // Login agent
                    foreach (IAgent Agt in theSession.Agents)
                    {
                        if (Agt.StaticVoiceTerminal == (IAgentTerminal)chosenTerminal)
                        {
                            try
                            {
                                Agt.Login();
                            }
                            catch (Exception Ex)
                            {
                                mText.ForeColor = Color.Red;
                                mText.Text = "FAILED";
                                mError.Text = Ex.Message;
                            }
                        }
                    }
                }
            }
        }

        private void mAready_Click(object sender, EventArgs e)
        {
            if (bAgtAddr && !bDisableAgt)
            {
                if (bAgtLoggedIn)
                {
                    if (mAgent.IsReady)
                    {
                        try
                        {
                            mAgent.IsReady = false;
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                    else
                    {
                        try
                        {
                            mAgent.IsReady = true;
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                }
            }
        }

        private void mAxfer_Click(object sender, EventArgs e)
        {
            if (bAgtAddr && !bDisableAgt)
            {
                if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse)
                {
                    if (!bPendingXfer)
                    {
                        // Blind transfer not supported in SIP
                        try
                        {
                            XferContact = mConnect.InitiateSupervisedTransfer(mAxferNum.Text);
                            bPendingXfer = true;
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                }
            }
        }

        private void mStringBut_Click(object sender, EventArgs e)
        {
            if (!mStringt.Enabled)
            {
                mStringBut.Text = "SET";
                mStringt.Enabled = true;
            }
            else
            {
                AttachedData tempSData = new AttachedData(mStringt.Text);

                try
                {
                    mConnect.Contact.Data = tempSData;
                }
                catch (Exception Ex)
                {
                    mText.ForeColor = Color.Red;
                    mText.Text = "FAILED";
                    mError.Text = Ex.Message;
                }
                mStringBut.Text = "String";
                mStringt.Enabled = false;
            }
        }

        private void mBinBut_Click(object sender, EventArgs e)
        {
            if (!mBinaryt.Enabled)
            {
                mBinBut.Text = "SET";
                mBinaryt.Enabled = true;
            }
            else
            {
                AttachedData tempBData = new AttachedData(System.Text.Encoding.UTF8.GetBytes(mBinaryt.Text));

                try
                {
                    mConnect.Contact.Data = tempBData;
                }
                catch (Exception Ex)
                {
                    mText.ForeColor = Color.Red;
                    mText.Text = "FAILED";
                    mError.Text = Ex.Message;
                }

                mBinBut.Text = "Binary";
                mBinaryt.Enabled = false;
            }
        }

        private void CheckAddressState()
        {
            ResetButtons();

            if (chosenAddress is IAgentAddress)
            {
                chosenAddress = mAddr.SelectedItem as IAgentAddress;

                bAgtAddr = true;
                bAgtLoggedIn = false;

                mAgtButton.Enabled = true;

                // Check if already logged on
                foreach (IAgent agt in theSession.Agents)
                {
                    if (agt.IsLoggedIn)
                    {
                        foreach (IAgentTerminal agtT in agt.Terminals)
                        {
                            if (agtT.DefaultContactType == "Voice") // Ignore multimedia terminals in the session
                            {
                                foreach (IAddress agtA in agtT.RelatedAddresses)
                                {
                                    if (agtA.Name == chosenAddress.Name)
                                    {
                                        bAgtLoggedIn = true;
                                        mAgent = agt;
                                        mAgtButton.Text = "Logout";
                                        mAready.Enabled = true;
                                        mAready.Text = (agt.IsReady) ? "Ready" : "NReady";
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                if (!bAgtLoggedIn) mAgtButton.Text = "AgentLogin";
                if (bSIPPBX) // Also enable outbound if SIP
                {
                    mMakeCall.Text = "MakeCall";
                    mMakeCall.Enabled = true;
                    mDialNum.Enabled = true;
                }
            }
            else
            {
                mMakeCall.Enabled = true;
                mDialNum.Enabled = true;
                bAgtAddr = false;
            }

            mText.ForeColor = Color.Green;
            mText.Text = "IDLE";

            existingConnects = chosenTerminal.TerminalConnections;

            // Check if connected to a call
            foreach (ITerminalConnection assignTC in existingConnects)
            {
                foreach (IAddress cAddr in assignTC.Terminal.RelatedAddresses)
                {
                    if (assignTC.Connection.Address.Name == chosenAddress.Name)
                    {
                        // Address is active
                        if (assignTC.CurrentState == TerminalConnectionState.Ringing || assignTC.CurrentState == TerminalConnectionState.Active || assignTC.CurrentState == TerminalConnectionState.Bridged || assignTC.CurrentState == TerminalConnectionState.InUse || assignTC.CurrentState == TerminalConnectionState.Held)
                        {
                            mState = assignTC.CurrentState;
                            mAddress = assignTC.Connection.Address;
                            mConnect = assignTC;

                            mText.ForeColor = Color.Green;
                            mText.Text = "ACTIVE";
                            mAddr.Enabled = false;

                            // Check for intrinsic
                            if ((assignTC.Contact.Intrinsics != null) && (assignTC.Contact.Capabilities.CanGetIntrinsics == true))
                            {
                                foreach(string IntrinsicID in assignTC.Contact.Intrinsics.Keys)
                                {
                                    if(IntrinsicID == "Skillset") mSkillsetTxt.Text = assignTC.Contact.Intrinsics[IntrinsicID];

                                    // SIP call this intrinsic is also stored as UUI data
                                    if(IntrinsicID == "SIP_CALLER_DISPLAY") mCLIDTxt.Text = assignTC.Contact.Intrinsics[IntrinsicID];
                                }
                            }

                            if (assignTC.CurrentState != TerminalConnectionState.Ringing) // Do not check for attached data on ringing
                            {
                                if (bSIPPBX) // Cannot check UUI unless SIP call
                                {
                                    // Check for UUI data
                                    UserUserInfo localUUI = assignTC.Contact.UUI;

                                    if ((localUUI != null) && (localUUI.StringData.Length > 0) && (assignTC.Contact.Capabilities.CanGetUUI == true))
                                    {
                                        mUUIBut.Enabled = true;
                                        if (localUUI.MayBeBinary)
                                        {
                                            StringBuilder text = new StringBuilder(1024);
                                            foreach (byte b in localUUI.BinaryData) text.AppendFormat("{0} ", b.ToString("X2"));
                                            mUUIt.Text = text.ToString();
                                        }
                                        else mUUIt.Text = localUUI.StringData;
                                    }
                                }

                                // Check for attached data
                                if ((assignTC.Contact.Data != null) && (assignTC.Contact.Capabilities.CanGetAttachedData == true))
                                {
                                    AttachedData tempAData = assignTC.Contact.Data;
                                    CheckData(tempAData);
                                }
                            }

                            if (bAgtAddr && !bDisableAgt) // Agent call
                            {
                                if (bSIPPBX) // Check agent call is inbound or outbound if SIP
                                {
                                    // Cater for both Agent and DN buttons
                                    if (assignTC.Contact.CallingAddress == chosenAddress.Name) // Call is outbound
                                    {
                                        mAgtButton.Enabled = false; // Disable agent login key

                                        if (assignTC.CurrentState == TerminalConnectionState.Ringing) // Ringback from far end
                                        {
                                            mMakeCall.Text = "HangUp";
                                            mMakeCall.Enabled = true;
                                            mDialNum.Enabled = false;
                                        }
                                        if (assignTC.CurrentState == TerminalConnectionState.Active || assignTC.CurrentState == TerminalConnectionState.Bridged || assignTC.CurrentState == TerminalConnectionState.InUse || assignTC.CurrentState == TerminalConnectionState.Held)
                                        {
                                            mMakeCall.Text = "HangUp";
                                            mMakeCall.Enabled = true;
                                            mDialNum.Enabled = false;
                                        }
                                    }
                                    else // Call is inbound
                                    {
                                        // Answer calls on Agent Login button
                                        mMakeCall.Enabled = false; // Disable outbound
                                        mDialNum.Enabled = false;

                                        if (assignTC.CurrentState == TerminalConnectionState.Ringing) // Local ringing
                                        {
                                            mAgtButton.Text = "Answer";
                                            mAgtButton.Enabled = true;
                                            mAxferNum.Enabled = false;
                                            mAxfer.Enabled = false;
                                            mAready.Enabled = false;
                                            mAConf.Enabled = false;
                                        }
                                        if (assignTC.CurrentState == TerminalConnectionState.Active || assignTC.CurrentState == TerminalConnectionState.Bridged || assignTC.CurrentState == TerminalConnectionState.InUse || assignTC.CurrentState == TerminalConnectionState.Held)
                                        {
                                            mAgtButton.Text = "Hangup";
                                            mAgtButton.Enabled = true;
                                            mAxferNum.Enabled = true;
                                            mAxfer.Enabled = true;
                                            mAready.Enabled = false;
                                            mAConf.Enabled = true;
                                        }
                                    }
                                }
                                else // non SIP agent - no outbound
                                {
                                    if (assignTC.CurrentState == TerminalConnectionState.Ringing)
                                    {
                                        mAgtButton.Text = "Answer";
                                        mAgtButton.Enabled = true;
                                        mAxferNum.Enabled = false;
                                        mAxfer.Enabled = false;
                                        mAready.Enabled = false;
                                        mAConf.Enabled = false;
                                    }
                                    if (assignTC.CurrentState == TerminalConnectionState.Active || assignTC.CurrentState == TerminalConnectionState.Bridged || assignTC.CurrentState == TerminalConnectionState.InUse)
                                    {
                                        mAgtButton.Text = "Hangup";
                                        mAgtButton.Enabled = true;
                                        mAxferNum.Enabled = true;
                                        mAxfer.Enabled = true;
                                        mAready.Enabled = false;
                                        mAConf.Enabled = true;
                                    }
                                    if (assignTC.CurrentState == TerminalConnectionState.Held)
                                    {
                                        // Hold buttons
                                    }
                                }
                            }
                            else // non SIP DN call
                            {
                                // non SIP answer on MakeCall button
                                if (assignTC.CurrentState == TerminalConnectionState.Ringing)
                                {
                                    if (assignTC.Contact.CallingAddress == chosenAddress.Name) // Call is outbound - ringback from far end
                                    {
                                        mMakeCall.Text = "Hangup";
                                    }
                                    else // Call is inbound - local rining
                                    {
                                        mMakeCall.Text = "Answer";
                                    }
                                    mMakeCall.Enabled = true;
                                    mDialNum.Enabled = false;
                                }
                                if (assignTC.CurrentState == TerminalConnectionState.Active || assignTC.CurrentState == TerminalConnectionState.Bridged || assignTC.CurrentState == TerminalConnectionState.InUse || assignTC.CurrentState == TerminalConnectionState.Held)
                                {
                                    mMakeCall.Text = "HangUp";
                                    mMakeCall.Enabled = true;
                                    mDialNum.Enabled = false;
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }

        private void CheckData(AttachedData mData)
        {
            switch (mData.Format)
            {
                case AttachedDataFormat.Bin:
                    {
                        StringBuilder text = new StringBuilder(1024);
                        foreach (byte b in mData.BinaryData) text.AppendFormat("{0} ", b.ToString("X2"));
                        mBinaryt.Text = text.ToString();
                        mBinBut.Enabled = true;
                        mStringBut.Enabled = false;
                        mKVPBut.Enabled = false;
                        mKVP1t.Text = string.Empty;
                        mKVP2t.Text = string.Empty;
                        mStringt.Text = string.Empty;
                        break;
                    }
                case AttachedDataFormat.KVP:
                    {
                        IDictionaryEnumerator x = mData.KeyValuePairs;
                        // Get first key value pair
                        x.MoveNext();
                        mKVP1t.Text = (string)x.Key;
                        mKVP2t.Text = (string)x.Value;
                        mKVPBut.Enabled = true;
                        mStringBut.Enabled = false;
                        mBinBut.Enabled = false;
                        mBinaryt.Text = string.Empty;
                        mStringt.Text = string.Empty;
                        break;
                    }
                case AttachedDataFormat.Str:
                    {
                        mStringt.Text = mData.StringData;
                        mStringBut.Enabled = true;
                        mBinBut.Enabled = false;
                        mKVPBut.Enabled = false;
                        mBinaryt.Text = string.Empty;
                        mKVP1t.Text = string.Empty;
                        mKVP2t.Text = string.Empty;
                        break;
                    }
            }
        }

        private void ResetButtons()
        {
            mMakeCall.Enabled = false;
            mDialNum.Enabled = false;

            mAgtButton.Enabled = false;
            mAxfer.Enabled = false;
            mAxferNum.Enabled = false;
            mAready.Enabled = false;
            mAConf.Enabled = false;

            mUUIBut.Enabled = false;
            mStringBut.Enabled = false;
            mBinBut.Enabled = false;
            mKVPBut.Enabled = false;

            mStringt.Text = string.Empty;
            mKVP1t.Text = string.Empty;
            mKVP2t.Text = string.Empty;
            mBinaryt.Text = string.Empty;
            mUUIt.Text = string.Empty;

            mCLIDTxt.Text = string.Empty;
            mSkillsetTxt.Text = string.Empty;
        }

        private void mKVPBut_Click(object sender, EventArgs e)
        {
            if ((!mKVP1t.Enabled) && (!mKVP2t.Enabled))
            {
                mKVPBut.Text = "SET";
                mKVP1t.Enabled = true;
                mKVP2t.Enabled = true;
            }
            else
            {
                mError.Text = "BLAH";
                AttachedData tempKData = new AttachedData(AttachedDataFormat.KVP);

                try
                {
                    tempKData[mKVP1t.Text] = mKVP2t.Text;
                    mConnect.Contact.Data = tempKData;
                }
                catch (Exception Ex)
                {
                    mText.ForeColor = Color.Red;
                    mText.Text = "FAILED";
                    mError.Text = Ex.Message;
                }
                mKVPBut.Text = "KVP";
                mKVP1t.Enabled = false;
                mKVP2t.Enabled = false;
            }
        }

        private void mAConf_Click(object sender, EventArgs e)
        {
            if (bAgtAddr && !bDisableAgt)
            {
                if (mState == TerminalConnectionState.Active || mState == TerminalConnectionState.Bridged || mState == TerminalConnectionState.InUse)
                {
                    if (!bPendingConf)
                    {
                        try
                        {
                            ConfContact = mConnect.InitiateConference(mAxferNum.Text);
                            bPendingConf = true;
                        }
                        catch (Exception Ex)
                        {
                            mText.ForeColor = Color.Red;
                            mText.Text = "FAILED";
                            mError.Text = Ex.Message;
                        }
                    }
                }
            }
        }

        private void mUUIBut_Click(object sender, EventArgs e)
        {
            if (!mUUIt.Enabled)
            {
                mUUIBut.Text = "SET";
                mUUIt.Enabled = true;
            }
            else
            {
                UserUserInfo tempUData = new UserUserInfo(System.Text.Encoding.UTF8.GetBytes(mUUIt.Text));

                try
                {
                    mConnect.Contact.UUI = tempUData;
                }
                catch (Exception Ex)
                {
                    mText.ForeColor = Color.Red;
                    mText.Text = "FAILED";
                    mError.Text = Ex.Message;
                }

                mUUIBut.Text = "UUI";
                mUUIt.Enabled = false;
            }
        }

    }

}
