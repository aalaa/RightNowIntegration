﻿namespace WebCTI
{
    partial class WebCTICtrl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mKVP2t = new System.Windows.Forms.TextBox();
            this.mStringt = new System.Windows.Forms.TextBox();
            this.mBinaryt = new System.Windows.Forms.TextBox();
            this.mKVP1t = new System.Windows.Forms.TextBox();
            this.mUUIt = new System.Windows.Forms.TextBox();
            this.mStringBut = new System.Windows.Forms.Button();
            this.mBinBut = new System.Windows.Forms.Button();
            this.mKVPBut = new System.Windows.Forms.Button();
            this.mUUIBut = new System.Windows.Forms.Button();
            this.mLogin = new System.Windows.Forms.Button();
            this.mText = new System.Windows.Forms.Label();
            this.mLogout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.mServerIP = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mCCTDomain = new System.Windows.Forms.TextBox();
            this.mCCTPwd = new System.Windows.Forms.TextBox();
            this.mCCTUser = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.mTerminals = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.mMakeCall = new System.Windows.Forms.Button();
            this.mDialNum = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.mAgtButton = new System.Windows.Forms.Button();
            this.mAddr = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.mAxfer = new System.Windows.Forms.Button();
            this.mAxferNum = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.mAready = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.mAConf = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.mCLIDTxt = new System.Windows.Forms.Label();
            this.mSkillsetTxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.mError = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mKVP2t);
            this.groupBox1.Controls.Add(this.mStringt);
            this.groupBox1.Controls.Add(this.mBinaryt);
            this.groupBox1.Controls.Add(this.mKVP1t);
            this.groupBox1.Controls.Add(this.mUUIt);
            this.groupBox1.Controls.Add(this.mStringBut);
            this.groupBox1.Controls.Add(this.mBinBut);
            this.groupBox1.Controls.Add(this.mKVPBut);
            this.groupBox1.Controls.Add(this.mUUIBut);
            this.groupBox1.Location = new System.Drawing.Point(17, 210);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 208);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Call Attached Data";
            // 
            // mKVP2t
            // 
            this.mKVP2t.Enabled = false;
            this.mKVP2t.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mKVP2t.Location = new System.Drawing.Point(127, 182);
            this.mKVP2t.Name = "mKVP2t";
            this.mKVP2t.Size = new System.Drawing.Size(333, 24);
            this.mKVP2t.TabIndex = 26;
            // 
            // mStringt
            // 
            this.mStringt.Enabled = false;
            this.mStringt.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mStringt.Location = new System.Drawing.Point(127, 63);
            this.mStringt.Name = "mStringt";
            this.mStringt.Size = new System.Drawing.Size(333, 24);
            this.mStringt.TabIndex = 25;
            // 
            // mBinaryt
            // 
            this.mBinaryt.Enabled = false;
            this.mBinaryt.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mBinaryt.Location = new System.Drawing.Point(127, 113);
            this.mBinaryt.Name = "mBinaryt";
            this.mBinaryt.Size = new System.Drawing.Size(333, 24);
            this.mBinaryt.TabIndex = 24;
            // 
            // mKVP1t
            // 
            this.mKVP1t.Enabled = false;
            this.mKVP1t.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mKVP1t.Location = new System.Drawing.Point(127, 155);
            this.mKVP1t.Name = "mKVP1t";
            this.mKVP1t.Size = new System.Drawing.Size(333, 24);
            this.mKVP1t.TabIndex = 23;
            // 
            // mUUIt
            // 
            this.mUUIt.Enabled = false;
            this.mUUIt.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mUUIt.Location = new System.Drawing.Point(127, 26);
            this.mUUIt.Name = "mUUIt";
            this.mUUIt.Size = new System.Drawing.Size(333, 24);
            this.mUUIt.TabIndex = 8;
            // 
            // mStringBut
            // 
            this.mStringBut.Enabled = false;
            this.mStringBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mStringBut.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mStringBut.Location = new System.Drawing.Point(6, 60);
            this.mStringBut.Name = "mStringBut";
            this.mStringBut.Size = new System.Drawing.Size(94, 30);
            this.mStringBut.TabIndex = 22;
            this.mStringBut.Text = "String";
            this.mStringBut.UseVisualStyleBackColor = true;
            this.mStringBut.Click += new System.EventHandler(this.mStringBut_Click);
            // 
            // mBinBut
            // 
            this.mBinBut.Enabled = false;
            this.mBinBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mBinBut.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mBinBut.Location = new System.Drawing.Point(6, 106);
            this.mBinBut.Name = "mBinBut";
            this.mBinBut.Size = new System.Drawing.Size(94, 30);
            this.mBinBut.TabIndex = 21;
            this.mBinBut.Text = "Binary";
            this.mBinBut.UseVisualStyleBackColor = true;
            this.mBinBut.Click += new System.EventHandler(this.mBinBut_Click);
            // 
            // mKVPBut
            // 
            this.mKVPBut.Enabled = false;
            this.mKVPBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mKVPBut.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mKVPBut.Location = new System.Drawing.Point(6, 153);
            this.mKVPBut.Name = "mKVPBut";
            this.mKVPBut.Size = new System.Drawing.Size(94, 30);
            this.mKVPBut.TabIndex = 20;
            this.mKVPBut.Text = "KVP";
            this.mKVPBut.UseVisualStyleBackColor = true;
            this.mKVPBut.Click += new System.EventHandler(this.mKVPBut_Click);
            // 
            // mUUIBut
            // 
            this.mUUIBut.Enabled = false;
            this.mUUIBut.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mUUIBut.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mUUIBut.Location = new System.Drawing.Point(6, 19);
            this.mUUIBut.Name = "mUUIBut";
            this.mUUIBut.Size = new System.Drawing.Size(55, 30);
            this.mUUIBut.TabIndex = 19;
            this.mUUIBut.Text = "UUI";
            this.mUUIBut.UseVisualStyleBackColor = true;
            this.mUUIBut.Click += new System.EventHandler(this.mUUIBut_Click);
            // 
            // mLogin
            // 
            this.mLogin.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mLogin.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mLogin.Location = new System.Drawing.Point(17, 18);
            this.mLogin.Name = "mLogin";
            this.mLogin.Size = new System.Drawing.Size(121, 33);
            this.mLogin.TabIndex = 0;
            this.mLogin.Text = "Login";
            this.mLogin.UseVisualStyleBackColor = true;
            this.mLogin.Click += new System.EventHandler(this.mLogin_Click);
            // 
            // mText
            // 
            this.mText.AutoSize = true;
            this.mText.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mText.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mText.Location = new System.Drawing.Point(81, 156);
            this.mText.Name = "mText";
            this.mText.Size = new System.Drawing.Size(109, 17);
            this.mText.TabIndex = 1;
            this.mText.Text = "NOT LOGGED IN";
            // 
            // mLogout
            // 
            this.mLogout.Enabled = false;
            this.mLogout.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mLogout.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mLogout.Location = new System.Drawing.Point(17, 66);
            this.mLogout.Name = "mLogout";
            this.mLogout.Size = new System.Drawing.Size(121, 34);
            this.mLogout.TabIndex = 2;
            this.mLogout.Text = "Logout";
            this.mLogout.UseVisualStyleBackColor = true;
            this.mLogout.Click += new System.EventHandler(this.mLogout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Status:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.mServerIP);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.mCCTDomain);
            this.groupBox2.Controls.Add(this.mCCTPwd);
            this.groupBox2.Controls.Add(this.mCCTUser);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(184, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(299, 122);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CCT login credentials";
            // 
            // mServerIP
            // 
            this.mServerIP.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mServerIP.Location = new System.Drawing.Point(119, 94);
            this.mServerIP.Name = "mServerIP";
            this.mServerIP.Size = new System.Drawing.Size(174, 24);
            this.mServerIP.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label9.Location = new System.Drawing.Point(7, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "Server IP:";
            // 
            // mCCTDomain
            // 
            this.mCCTDomain.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mCCTDomain.Location = new System.Drawing.Point(119, 66);
            this.mCCTDomain.Name = "mCCTDomain";
            this.mCCTDomain.Size = new System.Drawing.Size(174, 24);
            this.mCCTDomain.TabIndex = 5;
            // 
            // mCCTPwd
            // 
            this.mCCTPwd.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mCCTPwd.Location = new System.Drawing.Point(119, 41);
            this.mCCTPwd.Name = "mCCTPwd";
            this.mCCTPwd.Size = new System.Drawing.Size(174, 24);
            this.mCCTPwd.TabIndex = 4;
            this.mCCTPwd.UseSystemPasswordChar = true;
            // 
            // mCCTUser
            // 
            this.mCCTUser.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mCCTUser.Location = new System.Drawing.Point(119, 17);
            this.mCCTUser.Name = "mCCTUser";
            this.mCCTUser.Size = new System.Drawing.Size(174, 24);
            this.mCCTUser.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label8.Location = new System.Drawing.Point(7, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Domain:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label7.Location = new System.Drawing.Point(7, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Password:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label6.Location = new System.Drawing.Point(7, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "User Name:";
            // 
            // mTerminals
            // 
            this.mTerminals.Enabled = false;
            this.mTerminals.FormattingEnabled = true;
            this.mTerminals.Location = new System.Drawing.Point(303, 156);
            this.mTerminals.Name = "mTerminals";
            this.mTerminals.Size = new System.Drawing.Size(174, 21);
            this.mTerminals.TabIndex = 10;
            this.mTerminals.SelectedIndexChanged += new System.EventHandler(this.mTerminals_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(216, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "Terminal:";
            // 
            // mMakeCall
            // 
            this.mMakeCall.Enabled = false;
            this.mMakeCall.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mMakeCall.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mMakeCall.Location = new System.Drawing.Point(6, 19);
            this.mMakeCall.Name = "mMakeCall";
            this.mMakeCall.Size = new System.Drawing.Size(94, 42);
            this.mMakeCall.TabIndex = 12;
            this.mMakeCall.Text = "MakeCall";
            this.mMakeCall.UseVisualStyleBackColor = true;
            this.mMakeCall.Click += new System.EventHandler(this.mMakeCall_Click);
            // 
            // mDialNum
            // 
            this.mDialNum.Enabled = false;
            this.mDialNum.Location = new System.Drawing.Point(127, 19);
            this.mDialNum.Name = "mDialNum";
            this.mDialNum.Size = new System.Drawing.Size(100, 20);
            this.mDialNum.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label12.Location = new System.Drawing.Point(106, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 17);
            this.label12.TabIndex = 13;
            this.label12.Text = "To";
            // 
            // mAgtButton
            // 
            this.mAgtButton.Enabled = false;
            this.mAgtButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mAgtButton.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mAgtButton.Location = new System.Drawing.Point(4, 19);
            this.mAgtButton.Name = "mAgtButton";
            this.mAgtButton.Size = new System.Drawing.Size(121, 42);
            this.mAgtButton.TabIndex = 17;
            this.mAgtButton.Text = "AgentLogin";
            this.mAgtButton.UseVisualStyleBackColor = true;
            this.mAgtButton.Click += new System.EventHandler(this.mAgtButton_Click);
            // 
            // mAddr
            // 
            this.mAddr.Enabled = false;
            this.mAddr.FormattingEnabled = true;
            this.mAddr.Location = new System.Drawing.Point(303, 183);
            this.mAddr.Name = "mAddr";
            this.mAddr.Size = new System.Drawing.Size(174, 21);
            this.mAddr.TabIndex = 22;
            this.mAddr.SelectedIndexChanged += new System.EventHandler(this.mAddr_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(216, 187);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 17);
            this.label16.TabIndex = 23;
            this.label16.Text = "Address:";
            // 
            // mAxfer
            // 
            this.mAxfer.Enabled = false;
            this.mAxfer.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mAxfer.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mAxfer.Location = new System.Drawing.Point(231, 11);
            this.mAxfer.Name = "mAxfer";
            this.mAxfer.Size = new System.Drawing.Size(94, 28);
            this.mAxfer.TabIndex = 24;
            this.mAxfer.Text = "Transfer";
            this.mAxfer.UseVisualStyleBackColor = true;
            this.mAxfer.Click += new System.EventHandler(this.mAxfer_Click);
            // 
            // mAxferNum
            // 
            this.mAxferNum.Enabled = false;
            this.mAxferNum.Location = new System.Drawing.Point(356, 11);
            this.mAxferNum.Name = "mAxferNum";
            this.mAxferNum.Size = new System.Drawing.Size(100, 20);
            this.mAxferNum.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label11.Location = new System.Drawing.Point(329, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 17);
            this.label11.TabIndex = 26;
            this.label11.Text = "To";
            // 
            // mAready
            // 
            this.mAready.Enabled = false;
            this.mAready.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mAready.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mAready.Location = new System.Drawing.Point(131, 19);
            this.mAready.Name = "mAready";
            this.mAready.Size = new System.Drawing.Size(83, 42);
            this.mAready.TabIndex = 27;
            this.mAready.Text = "Ready";
            this.mAready.UseVisualStyleBackColor = true;
            this.mAready.Click += new System.EventHandler(this.mAready_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.mDialNum);
            this.groupBox3.Controls.Add(this.mMakeCall);
            this.groupBox3.Location = new System.Drawing.Point(17, 473);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(465, 78);
            this.groupBox3.TabIndex = 28;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Personal";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.mAConf);
            this.groupBox4.Controls.Add(this.mAready);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.mAxferNum);
            this.groupBox4.Controls.Add(this.mAxfer);
            this.groupBox4.Controls.Add(this.mAgtButton);
            this.groupBox4.Location = new System.Drawing.Point(19, 557);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(462, 76);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Agent";
            // 
            // mAConf
            // 
            this.mAConf.Enabled = false;
            this.mAConf.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mAConf.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.mAConf.Location = new System.Drawing.Point(231, 43);
            this.mAConf.Name = "mAConf";
            this.mAConf.Size = new System.Drawing.Size(122, 28);
            this.mAConf.TabIndex = 28;
            this.mAConf.Text = "Conference";
            this.mAConf.UseVisualStyleBackColor = true;
            this.mAConf.Click += new System.EventHandler(this.mAConf_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.mCLIDTxt);
            this.groupBox5.Controls.Add(this.mSkillsetTxt);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Location = new System.Drawing.Point(17, 424);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(464, 43);
            this.groupBox5.TabIndex = 30;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Intrinsics";
            // 
            // mCLIDTxt
            // 
            this.mCLIDTxt.AutoSize = true;
            this.mCLIDTxt.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mCLIDTxt.Location = new System.Drawing.Point(342, 16);
            this.mCLIDTxt.Name = "mCLIDTxt";
            this.mCLIDTxt.Size = new System.Drawing.Size(0, 17);
            this.mCLIDTxt.TabIndex = 12;
            // 
            // mSkillsetTxt
            // 
            this.mSkillsetTxt.AutoSize = true;
            this.mSkillsetTxt.Font = new System.Drawing.Font("Tahoma", 10F);
            this.mSkillsetTxt.Location = new System.Drawing.Point(69, 16);
            this.mSkillsetTxt.Name = "mSkillsetTxt";
            this.mSkillsetTxt.Size = new System.Drawing.Size(0, 17);
            this.mSkillsetTxt.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label3.Location = new System.Drawing.Point(230, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Calling Line ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Skillset:";
            // 
            // mError
            // 
            this.mError.AutoSize = true;
            this.mError.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mError.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mError.Location = new System.Drawing.Point(16, 645);
            this.mError.Name = "mError";
            this.mError.Size = new System.Drawing.Size(0, 17);
            this.mError.TabIndex = 31;
            // 
            // WebCTICtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Controls.Add(this.mError);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.mAddr);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.mTerminals);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mLogout);
            this.Controls.Add(this.mText);
            this.Controls.Add(this.mLogin);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Name = "WebCTICtrl";
            this.Size = new System.Drawing.Size(543, 672);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button mLogin;
        private System.Windows.Forms.Label mText;
        private System.Windows.Forms.Button mLogout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox mServerIP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox mCCTDomain;
        private System.Windows.Forms.TextBox mCCTPwd;
        private System.Windows.Forms.TextBox mCCTUser;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox mTerminals;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button mMakeCall;
        private System.Windows.Forms.TextBox mDialNum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button mAgtButton;
        private System.Windows.Forms.ComboBox mAddr;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button mAxfer;
        private System.Windows.Forms.TextBox mAxferNum;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button mAready;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button mStringBut;
        private System.Windows.Forms.Button mBinBut;
        private System.Windows.Forms.Button mKVPBut;
        private System.Windows.Forms.Button mUUIBut;
        private System.Windows.Forms.TextBox mUUIt;
        private System.Windows.Forms.TextBox mKVP2t;
        private System.Windows.Forms.TextBox mStringt;
        private System.Windows.Forms.TextBox mBinaryt;
        private System.Windows.Forms.TextBox mKVP1t;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label mCLIDTxt;
        private System.Windows.Forms.Label mSkillsetTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button mAConf;
        private System.Windows.Forms.Label mError;

    }
}
